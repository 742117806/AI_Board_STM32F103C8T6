#ifndef __CECODEC74_H
#define __CECODEC74_H
#include "stdint.h"

uint16_t code16_74bit(uint8_t InData);
uint8_t decode16_74bit(uint16_t InData);
#endif
