
#ifndef __TASKAPP_H__
#define __TASKAPP_H__

#include "stm32f1xx.h"
//#include "RTL.h"
#include "delay.h"
#include "uart.h"

#include "wireless_app.h"
/* 
********************************************************************************************************** 
                      函数声明 
********************************************************************************************************** 
*/

void RTX_OS_Init(void);


#endif

